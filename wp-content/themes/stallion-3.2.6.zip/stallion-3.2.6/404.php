<?php get_header(); ?>

	<div class="article">
		<div class="container">
			<div class="row"><div class="span12">
				<div class="article-heading-block"><div class="row">
					<div class="span12">
						<div class="fullwidth-errormessage" style="margin:50px 10% 200px 10%">
							<h3>Page not found.</h3>
							<p>The page you were looking for doesn't exist.</p>
							<p>If you followed a faulty link from another website, please let them know.<br />If you believe the problem is our error, please get in touch.</p>
							<p>Sorry about that.</p>
						</div>
					</div>
					<div style="clear:both"></div>
				</div></div>
			</div></div>
		</div>
	</div>

<?php get_footer(); ?>