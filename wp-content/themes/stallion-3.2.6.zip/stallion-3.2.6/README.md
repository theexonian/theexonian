![The Project for Better Journalism](http://betterjournalism.org/static/logo.png)


### PBJ Stallion

[The Project for Better Journalism](http://betterjournalism.org) is a grassroots effort to empower students through journalism and collaboration. We're fostering an atmosphere of transparency and strengthening journalism in schools across the country.

Stallion, in conjunction with WordPress, powers the Project network. It's installed as a theme -- find [install guidelines](http://betterjournalism.org/i/deployment/technicalsteps/) here.
